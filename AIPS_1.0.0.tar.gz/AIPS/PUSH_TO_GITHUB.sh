git push -u origin master

