### R code from vignette source 'AIPS.Rnw'

###################################################
### code chunk number 1: loadPackages
###################################################
library(AIPS)
data(mcgill.gq)


###################################################
### code chunk number 2: showMcGill
###################################################
dim(mcgill.gq$D)
head(mcgill.gq$D[,1:5])
head(mcgill.gq$EntrezID)


###################################################
### code chunk number 3: assignSubtypeToMcGill
###################################################
mcgill.aips <- apply.AIPS(mcgill.gq$D[,1:5],
                          mcgill.gq$EntrezID)
## Number of low, random and high assignments for the first sample
## table(mcgill.aips$cl[,1])

## Number of low, random and high assignments for the second sample
## table(mcgill.aips$cl[,2])



###################################################
### code chunk number 4: assigneSampleOneSubtypeMcGill
###################################################
mcgill.first.sample.aips <- apply.AIPS(mcgill.gq$D[,1:5,drop=FALSE],
                                            mcgill.gq$EntrezID)
## compare the single versus 5 samples assignments
## table(mcgill.aips$cl[,1],mcgill.first.sample.aips$cl[,1])


###################################################
### code chunk number 5: assignSubtypeToVDX
###################################################
library(breastCancerVDX)
library(hgu133a.db)
data(vdx)

hgu133a.entrez <- as.character(as.list(hgu133aENTREZID)[featureNames(vdx)])
vdx.aips <- apply.AIPS(exprs(vdx)[,1:5],
                       hgu133a.entrez)

mclvdx.aips <- mclapply.AIPS(exprs(vdx)[,1:5],
                       hgu133a.entrez)
## table(vdx.aips$cl[,1])


###################################################
### code chunk number 6: sessionInfo
###################################################
toLatex(sessionInfo())


